// Main JavaScript for LinkedIn Portfolio Generator

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize modals
    const loginLink = document.querySelector('a[href="#login"]');
    const registerLink = document.querySelector('a[href="#register"]');
    
    if (loginLink) {
        loginLink.addEventListener('click', function(e) {
            e.preventDefault();
            const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
            loginModal.show();
        });
    }
    
    if (registerLink) {
        registerLink.addEventListener('click', function(e) {
            e.preventDefault();
            const registerModal = new bootstrap.Modal(document.getElementById('registerModal'));
            registerModal.show();
        });
    }

    // Form validation
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            validateLoginForm();
        });
    }
    
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            validateRegisterForm();
        });
    }

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]:not([data-bs-toggle])').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#login' || targetId === '#register') {
                return; // These are handled by modal triggers
            }
            
            e.preventDefault();
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 70,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Add animation to elements when they come into view
    const animateOnScroll = function() {
        const elements = document.querySelectorAll('.card, .feature-icon, .step-number');
        
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            
            if (elementPosition < windowHeight - 50) {
                element.classList.add('fade-in');
            }
        });
    };

    // Run animation check on scroll
    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll(); // Run once on page load
});

// Form validation functions
function validateLoginForm() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    let isValid = true;
    
    // Simple email validation
    if (!isValidEmail(email)) {
        showError('loginEmail', 'Please enter a valid email address');
        isValid = false;
    } else {
        clearError('loginEmail');
    }
    
    // Password validation
    if (password.length < 1) {
        showError('loginPassword', 'Please enter your password');
        isValid = false;
    } else {
        clearError('loginPassword');
    }
    
    if (isValid) {
        // In a real application, this would submit to the server
        // For demo purposes, show success message
        alert('Login successful! (Demo only)');
        bootstrap.Modal.getInstance(document.getElementById('loginModal')).hide();
    }
}

function validateRegisterForm() {
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const agreeTerms = document.getElementById('agreeTerms').checked;
    let isValid = true;
    
    // Name validation
    if (name.length < 2) {
        showError('registerName', 'Name must be at least 2 characters');
        isValid = false;
    } else {
        clearError('registerName');
    }
    
    // Email validation
    if (!isValidEmail(email)) {
        showError('registerEmail', 'Please enter a valid email address');
        isValid = false;
    } else {
        clearError('registerEmail');
    }
    
    // Password validation
    if (password.length < 12) {
        showError('registerPassword', 'Password must be at least 12 characters');
        isValid = false;
    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/.test(password)) {
        showError('registerPassword', 'Password must include uppercase, lowercase, number, and special character');
        isValid = false;
    } else {
        clearError('registerPassword');
    }
    
    // Confirm password
    if (password !== confirmPassword) {
        showError('confirmPassword', 'Passwords do not match');
        isValid = false;
    } else {
        clearError('confirmPassword');
    }
    
    // Terms agreement
    if (!agreeTerms) {
        showError('agreeTerms', 'You must agree to the terms');
        isValid = false;
    } else {
        clearError('agreeTerms');
    }
    
    if (isValid) {
        // In a real application, this would submit to the server
        // For demo purposes, show success message
        alert('Registration successful! (Demo only)');
        bootstrap.Modal.getInstance(document.getElementById('registerModal')).hide();
    }
}

// Helper functions
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function showError(fieldId, message) {
    const field = document.getElementById(fieldId);
    field.classList.add('is-invalid');
    
    // Check if error message element already exists
    let errorElement = field.nextElementSibling;
    if (!errorElement || !errorElement.classList.contains('invalid-feedback')) {
        errorElement = document.createElement('div');
        errorElement.className = 'invalid-feedback';
        field.parentNode.insertBefore(errorElement, field.nextSibling);
    }
    
    errorElement.textContent = message;
}

function clearError(fieldId) {
    const field = document.getElementById(fieldId);
    field.classList.remove('is-invalid');
    
    // Remove error message if it exists
    const errorElement = field.nextElementSibling;
    if (errorElement && errorElement.classList.contains('invalid-feedback')) {
        errorElement.textContent = '';
    }
}

// Security enhancement - prevent XSS in form inputs
function sanitizeInput(input) {
    const div = document.createElement('div');
    div.textContent = input;
    return div.innerHTML;
}
