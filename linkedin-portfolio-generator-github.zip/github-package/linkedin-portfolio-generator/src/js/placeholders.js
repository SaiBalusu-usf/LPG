// Generate placeholder images with text
document.addEventListener('DOMContentLoaded', function() {
  // Add placeholder CSS
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = 'css/placeholder.css';
  document.head.appendChild(link);
  
  // Create hero image placeholder
  const heroImage = document.querySelector('.hero-section .img-fluid');
  if (heroImage) {
    const heroPlaceholder = document.createElement('div');
    heroPlaceholder.className = 'placeholder-img hero-img';
    heroPlaceholder.innerHTML = '<div>Portfolio Preview</div>';
    heroImage.parentNode.replaceChild(heroPlaceholder, heroImage);
  }
  
  // Create template image placeholders
  const templateImages = document.querySelectorAll('.card-img-top');
  templateImages.forEach((img, index) => {
    const templateNames = ['Modern Template', 'Classic Template', 'Creative Template'];
    const placeholder = document.createElement('div');
    placeholder.className = 'placeholder-img template-img';
    placeholder.innerHTML = `<div>${templateNames[index] || 'Template Design'}</div>`;
    img.parentNode.replaceChild(placeholder, img);
  });
  
  // Create testimonial image placeholders
  const testimonialImages = document.querySelectorAll('.testimonial-img');
  testimonialImages.forEach((img, index) => {
    const initials = ['SJ', 'MC', 'ER'];
    const placeholder = document.createElement('div');
    placeholder.className = 'testimonial-img rounded-circle';
    placeholder.innerHTML = initials[index] || 'U';
    img.parentNode.replaceChild(placeholder, img);
  });
});
