# Deployment Guide

This document provides instructions for deploying the LinkedIn Portfolio Generator in various environments, from local development to production.

## Table of Contents
- [Local Development](#local-development)
- [Staging Environment](#staging-environment)
- [Production Deployment](#production-deployment)
- [Docker Deployment](#docker-deployment)
- [Static Site Deployment](#static-site-deployment)
- [Continuous Integration/Deployment](#continuous-integrationdeployment)
- [Monitoring and Maintenance](#monitoring-and-maintenance)

## Local Development

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn
- MongoDB (local or remote)
- Redis (optional, for caching)

### Setup Steps

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/linkedin-portfolio-generator.git
   cd linkedin-portfolio-generator
   ```

2. Install dependencies:
   ```bash
   npm install
   # or
   yarn install
   ```

3. Set up environment variables:
   ```bash
   cp .env.example .env
   # Edit .env with your local configuration
   ```

4. Start the development server:
   ```bash
   npm run dev
   # or
   yarn dev
   ```

5. Access the application at `http://localhost:3000`

## Staging Environment

Staging deployment mirrors the production environment but is used for testing before releasing to production.

### Prerequisites
- CI/CD pipeline (GitHub Actions, Jenkins, etc.)
- Staging server or cloud environment
- MongoDB and Redis instances

### Deployment Steps

1. Configure staging environment variables:
   ```bash
   # On your CI/CD platform
   # Set all required environment variables for staging
   ```

2. Deploy via CI/CD pipeline:
   ```bash
   # Example GitHub Actions workflow
   npm run build
   npm run deploy:staging
   ```

3. Run database migrations:
   ```bash
   npm run migrate
   ```

4. Verify deployment:
   - Check application health at `https://staging.yourapp.com/health`
   - Run automated tests against staging environment
   - Perform manual QA testing

## Production Deployment

### Prerequisites
- Production server or cloud environment (AWS, GCP, Azure, etc.)
- Domain name and SSL certificate
- MongoDB and Redis production instances
- Load balancer (for high availability)

### Deployment Steps

1. Configure production environment variables:
   ```bash
   # On your production environment
   # Set all required environment variables with production values
   ```

2. Build the application:
   ```bash
   npm run build
   ```

3. Deploy the built application:
   ```bash
   # Using your preferred deployment method
   npm run deploy:production
   ```

4. Configure web server (Nginx example):
   ```nginx
   server {
       listen 80;
       server_name yourapp.com www.yourapp.com;
       
       # Redirect HTTP to HTTPS
       return 301 https://$host$request_uri;
   }

   server {
       listen 443 ssl;
       server_name yourapp.com www.yourapp.com;

       # SSL configuration
       ssl_certificate /path/to/cert.pem;
       ssl_certificate_key /path/to/key.pem;
       ssl_protocols TLSv1.2 TLSv1.3;
       
       # Security headers
       add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
       add_header X-Content-Type-Options "nosniff" always;
       add_header X-Frame-Options "DENY" always;
       add_header X-XSS-Protection "1; mode=block" always;
       add_header Content-Security-Policy "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none'; media-src 'self'; frame-src 'none'; form-action 'self'; base-uri 'self';" always;
       add_header Referrer-Policy "strict-origin-when-cross-origin" always;
       
       # Proxy to Node.js application
       location / {
           proxy_pass http://localhost:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

5. Set up database backups:
   ```bash
   # Example cron job for daily MongoDB backups
   0 2 * * * /path/to/backup-script.sh
   ```

## Docker Deployment

### Prerequisites
- Docker and Docker Compose
- Docker registry (optional, for private images)

### Deployment Steps

1. Build Docker images:
   ```bash
   docker-compose build
   ```

2. Run the application:
   ```bash
   docker-compose up -d
   ```

3. For production Docker deployment:
   ```bash
   docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d
   ```

4. Scale services as needed:
   ```bash
   docker-compose up -d --scale app=3
   ```

## Static Site Deployment

For the static site version of the application (frontend only):

### Prerequisites
- Static site hosting service (Netlify, Vercel, GitHub Pages, etc.)
- Build tools (Node.js, npm/yarn)

### Deployment Steps

1. Build the static site:
   ```bash
   npm run build:static
   ```

2. Deploy to hosting service:
   ```bash
   # Example for Netlify
   netlify deploy --prod
   
   # Example for Vercel
   vercel --prod
   
   # Example for GitHub Pages
   npm run deploy:gh-pages
   ```

3. Configure custom domain and SSL:
   - Add your domain in the hosting service dashboard
   - Set up DNS records as instructed by your hosting provider
   - Enable HTTPS/SSL

## Continuous Integration/Deployment

### GitHub Actions Example

Create a file at `.github/workflows/deploy.yml`:

```yaml
name: Deploy

on:
  push:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Use Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '14'
      - run: npm ci
      - run: npm test

  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Use Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '14'
      - run: npm ci
      - run: npm run build
      - name: Deploy to production
        run: npm run deploy:production
        env:
          DEPLOY_TOKEN: ${{ secrets.DEPLOY_TOKEN }}
```

## Monitoring and Maintenance

### Health Checks

Implement a health check endpoint at `/health` that returns:
- Application status
- Database connection status
- External service dependencies status

### Logging

Configure logging to capture important events:
```javascript
// Example logging setup
const winston = require('winston');
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  defaultMeta: { service: 'linkedin-portfolio-generator' },
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});
```

### Monitoring

Set up monitoring tools:
- Prometheus for metrics collection
- Grafana for visualization
- Alerting for critical issues

### Backup Strategy

1. Database backups:
   - Daily full backups
   - Hourly incremental backups
   - Retention policy: 30 days

2. Application state:
   - Configuration backups
   - User uploads backup

3. Disaster recovery:
   - Document recovery procedures
   - Regular recovery testing

---

This deployment guide should be adapted to your specific infrastructure and requirements.
